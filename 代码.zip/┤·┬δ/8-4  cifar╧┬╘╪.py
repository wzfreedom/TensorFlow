# -*- coding: utf-8 -*-
"""
Created on Mon Jun  5 22:02:23 2017

@author: 代码医生 qq群：40016981，公众号：xiangyuejiqiren
@blog：http://blog.csdn.net/lijin6249
"""
#放在cifar目录下
import cifar10
cifar10.maybe_download_and_extract()